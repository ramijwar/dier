package com.deir.deir_services

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
