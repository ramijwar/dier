/// إعدادات التطبيق — نفس مسار الـ API الخاص بتطبيق الويب.
///
/// الإنتاج (استضافة cPanel):  https://t3lam.site/next/api
///
/// للاختبار محلياً مع خادم PHP (php -S 127.0.0.1:8000):
///   - من محاكي أندرويد:   http://10.0.2.2:8000/api
///   - من هاتف حقيقي:      http://<عنوان-جهازك>:8000/api
const String kApiBase = "https://t3lam.site/next/api";

const String kAppName = "خدمات الدير";
const String kAppRegion = "محافظة دير الزور";
