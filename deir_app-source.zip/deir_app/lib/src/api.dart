import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'config.dart';
import 'models.dart';

class ApiException implements Exception {
  final String message;
  final int status;

  ApiException(this.message, this.status);
}

/// عميل الـ API — نفس المسارات التي يستخدمها تطبيق الويب.
class ApiClient {
  static const _tokenKey = "deir_token";
  static const _userKey = "deir_user";

  String? _token;
  User? _user;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_tokenKey);
    final raw = prefs.getString(_userKey);
    if (raw != null) {
      try {
        _user = User.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        _user = null;
      }
    }
  }

  String? get token => _token;
  User? get user => _user;

  Future<void> saveSession({required String token, required User user}) async {
    _token = token;
    _user = user;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_userKey, jsonEncode(user.toJson()));
  }

  Future<void> clearSession() async {
    _token = null;
    _user = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
  }) async {
    try {
      final uri = Uri.parse("$kApiBase$path");
      final headers = <String, String>{
        "Accept": "application/json",
      };
      if (body != null) {
        headers["Content-Type"] = "application/json";
      }
      if (_token != null) {
        headers["Authorization"] = "Bearer $_token";
      }
      final req = http.Request(method, uri);
      req.headers.addAll(headers);
      if (body != null) {
        req.body = jsonEncode(body);
        req.headers["Content-Type"] = "application/json";
      }
      final client = http.Client();
      late final http.Response res;
      try {
        final streamed = await client.send(req).timeout(const Duration(seconds: 20));
        res = await http.Response.fromStream(streamed);
      } finally {
        client.close();
      }
      final data = res.body.isEmpty ? <String, dynamic>{} : jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode >= 400) {
        throw ApiException((data["error"] as String?) ?? "حدث خطأ غير متوقع", res.statusCode);
      }
      return data;
    } on ApiException {
      rethrow;
    } on http.ClientException catch (e) {
      throw ApiException("تعذر الاتصال بالخادم: $e", 0);
    } catch (e) {
      throw ApiException("خطأ غير متوقع: $e", 0);
    }
  }

  // ---------- auth ----------
  Future<Map<String, dynamic>> login({required String email, required String password}) =>
      _request("POST", "/auth/login", body: {"email": email, "password": password});

  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    String phone = "",
  }) =>
      _request("POST", "/auth/register", body: {"name": name, "email": email, "password": password, "phone": phone});

  // ---------- public ----------
  Future<List<Section>> sections() async {
    final data = await _request("GET", "/sections");
    return ((data["sections"] as List))
        .map((e) => Section.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Map<String, dynamic>> sectionMeta(String slug) => _request("GET", "/sections/$slug");

  Future<List<Service>> services(Map<String, String> query) async {
    final qs = query.entries.map((e) => "${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}").join("&");
    final data = await _request("GET", "/services${qs.isEmpty ? "" : "?$qs"}");
    return ((data["services"] as List))
        .map((e) => Service.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Service> service(int id) async =>
      Service.fromJson((await _request("GET", "/services/$id"))["service"] as Map<String, dynamic>);

  // ---------- owner ----------
  Future<List<Service>> myServices() async {
    final data = await _request("GET", "/owner/services");
    return ((data["services"] as List))
        .map((e) => Service.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Service> createService(Map<String, dynamic> payload) async =>
      Service.fromJson((await _request("POST", "/owner/services", body: payload))["service"] as Map<String, dynamic>);

  Future<Service> updateService(int id, Map<String, dynamic> payload) async =>
      Service.fromJson((await _request("PUT", "/owner/services/$id", body: payload))["service"] as Map<String, dynamic>);

  Future<void> setServiceStatus(int id, String status) =>
      _request("PATCH", "/owner/services/$id/status", body: {"status": status});

  Future<void> deleteService(int id) => _request("DELETE", "/owner/services/$id");
}

extension UserJson on User {
  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "email": email,
        "phone": phone,
        "role": role,
        "created_at": createdAt,
      };
}
