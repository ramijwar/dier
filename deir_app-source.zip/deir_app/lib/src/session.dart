import 'package:flutter/foundation.dart';

import 'api.dart';
import 'models.dart';

/// حالة الجلسة (المستخدم الحالي) — تُحدّث عبر كل الشاشات.
class Session extends ChangeNotifier {
  static final Session instance = Session._();
  Session._();

  final ApiClient api = ApiClient();
  User? _user;

  User? get user => _user;
  bool get isAuthed => _user != null;

  Future<void> init() async {
    await api.init();
    _user = api.user;
    notifyListeners();
  }

  Future<void> onLogin(Map<String, dynamic> data) async {
    await api.saveSession(
      token: data["token"] as String,
      user: User.fromJson(data["user"] as Map<String, dynamic>),
    );
    _user = api.user;
    notifyListeners();
  }

  Future<void> logout() async {
    await api.clearSession();
    _user = null;
    notifyListeners();
  }

  void refresh() {
    _user = api.user;
    notifyListeners();
  }
}
