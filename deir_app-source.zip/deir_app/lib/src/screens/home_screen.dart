import 'package:flutter/material.dart';
import '../models.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/section_card.dart';
import 'section_screen.dart';

/// الرئيسية — مطابقة للويب: هيرو متدرج + بحث + أقسام + مزايا.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final _searchController = TextEditingController();
  late final AnimationController _intro = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
  List<Section> _sections = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _intro.forward();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _intro.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final s = await Session.instance.api.sections();
      if (mounted) setState(() => _sections = s);
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _loaded = true);
    }
  }

  void _openSection(String slug, {String? q}) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SectionScreen(slug: slug, initialQuery: q)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _Hero(
            sections: _sections,
            searchController: _searchController,
            intro: _intro,
            onSearch: (q) => _openSection("all", q: q.trim().isEmpty ? null : q.trim()),
            onChip: _openSection,
          ),
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("تصفح الأقسام", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: C.slate900)),
              TextButton(
                onPressed: () => _openSection("all"),
                child: const Text("كل الخدمات ←", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.emerald700)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (!_loaded)
            Column(children: List.generate(5, (_) => const Padding(padding: EdgeInsets.only(bottom: 16), child: SkeletonCard())))
          else
            Column(
              children: _sections
                  .map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: SectionCard(section: s, onTap: () => _openSection(s.slug)),
                      ))
                  .toList(),
            ),
          const SizedBox(height: 24),
          ...const [
            _Feature(icon: Icons.my_location, title: "القريبون منك", desc: "اضغط زر «القريبون مني» في أي قسم وسيتم ترتيب الخدمات حسب مسافتك", iconColor: C.emerald600, iconBg: C.emerald50),
            SizedBox(height: 16),
            _Feature(icon: Icons.schedule, title: "الدوام والمناوبة", desc: "حالة كل خدمة لحظة بلحظة: مفتوح الآن، مغلق، أو على المناوبة", iconColor: C.sky600, iconBg: C.sky50),
            SizedBox(height: 16),
            _Feature(icon: Icons.construction, title: "لوحة تحكم للخدمات", desc: "سجل حسابك وأضف خدمتك، وحدد أوقات الدوام وحالتها بنفسك", iconColor: C.violet600, iconBg: C.violet50),
          ],
        ],
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final List<Section> sections;
  final TextEditingController searchController;
  final AnimationController intro;
  final void Function(String q) onSearch;
  final void Function(String slug) onChip;

  const _Hero({
    required this.sections,
    required this.searchController,
    required this.intro,
    required this.onSearch,
    required this.onChip,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: intro,
      builder: (context, child) => Opacity(
        opacity: intro.value,
        child: Transform.translate(offset: Offset(0, 16 * (1 - intro.value)), child: child),
      ),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(24)),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [C.emerald700, C.teal700, C.slate900],
          ),
          boxShadow: [BoxShadow(color: Color(0x1A047857), blurRadius: 24, offset: Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
              ),
              child: const Text("🕌 دليل محافظة دير الزور", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFFA7F3D0))),
            ),
            const SizedBox(height: 20),
            const Text("كل خدمات الدير", style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2)),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFA7F3D0), Colors.white],
                begin: Alignment.centerRight,
                end: Alignment.centerLeft,
              ).createShader(bounds),
              child: const Text(
                "في مكان واحد",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "صيدليات وعيادات أطباء ومشافي وسرفيس نقل وكازيات — اعرف من يعمل الآن ومن على المناوبة، وحدد موقعك لعرض أقرب الخدمات إليك.",
              style: TextStyle(fontSize: 15, height: 1.6, color: Color(0x9BECFDF5)),
            ),
            const SizedBox(height: 24),
            // البحث
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Row(
                children: [
                  const Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Icon(Icons.search, size: 19, color: C.slate400),
                  ),
                  Expanded(
                    child: TextField(
                      controller: searchController,
                      onSubmitted: onSearch,
                      style: const TextStyle(fontSize: 14, color: C.slate900),
                      decoration: const InputDecoration(
                        isCollapsed: true,
                        border: InputBorder.none,
                        hintText: "ابحث عن صيدلية، عيادة، مطعم، سرفيس...",
                        hintStyle: TextStyle(fontSize: 14, color: C.slate400),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: C.emerald600,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => onSearch(searchController.text),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                        child: Text("بحث", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (sections.isNotEmpty) ...[
              const SizedBox(height: 20),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: sections
                    .map((s) => InkWell(
                          borderRadius: BorderRadius.circular(999),
                          onTap: () => onChip(s.slug),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                            ),
                            child: Text(
                              "${s.icon} ${s.name}",
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final Color iconColor;
  final Color iconBg;

  const _Feature({
    required this.icon,
    required this.title,
    required this.desc,
    required this.iconColor,
    required this.iconBg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.slate200),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.slate900)),
          const SizedBox(height: 4),
          Text(desc, style: const TextStyle(fontSize: 14, height: 1.5, color: C.slate500)),
        ],
      ),
    );
  }
}
