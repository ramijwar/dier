import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/service_card.dart';
import 'detail_screen.dart';

/// صفحة القسم — مطابقة للويب: بحث + القريبون مني + منطقة + تصنيف
/// + حالة + فلاتر مخصصة + ترتيب حسب المسافة.
class SectionScreen extends StatefulWidget {
  final String slug;
  final String? initialQuery;

  const SectionScreen({super.key, required this.slug, this.initialQuery});

  @override
  State<SectionScreen> createState() => _SectionScreenState();
}

class _SectionScreenState extends State<SectionScreen> {
  Map<String, dynamic>? _meta;
  bool _notFound = false;
  bool _loading = true;
  List<Service> _services = [];

  String _q = "";
  String _area = "";
  String _classification = "";
  String _status = "";
  final Map<int, String> _custom = {};
  Position? _pos;
  bool _locating = false;
  final _searchController = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    if (widget.initialQuery != null && widget.initialQuery!.isNotEmpty) {
      _q = widget.initialQuery!;
      _searchController.text = _q;
    }
    _loadMeta();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _loadMeta() async {
    try {
      final m = await Session.instance.api.sectionMeta(widget.slug);
      if (mounted) {
        setState(() => _meta = m);
        _loadServices();
      }
    } catch (_) {
      if (mounted) setState(() => _notFound = true);
    }
  }

  Map<String, String> _query() {
    final q = <String, String>{};
    if (widget.slug != "all") q["section"] = widget.slug;
    if (_area.isNotEmpty) q["area_id"] = _area;
    if (_classification.isNotEmpty) q["classification_id"] = _classification;
    if (_status.isNotEmpty) q["status"] = _status;
    if (_q.trim().isNotEmpty) q["q"] = _q.trim();
    _custom.forEach((k, v) {
      if (v.isNotEmpty) q["filter_$k"] = v;
    });
    if (_pos != null) {
      q["lat"] = _pos!.latitude.toString();
      q["lng"] = _pos!.longitude.toString();
    }
    return q;
  }

  Future<void> _loadServices() async {
    setState(() => _loading = true);
    try {
      final list = await Session.instance.api.services(_query());
      if (mounted) setState(() => _services = list);
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _reload() => _loadServices();

  void _onSearchChanged(String v) {
    _q = v;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), _reload);
  }

  void _locate() async {
    if (_locating) return;
    setState(() => _locating = true);
    try {
      bool service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        appToast("الوضع الجغرافي مغلق — فعّله ثم حاول مجدداً");
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        appToast("تعذر تحديد موقعك — اسمح للمتصفح بالوصول ثم حاول مجدداً");
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 10)),
      );
      if (mounted) {
        setState(() => _pos = pos);
        _reload();
      }
    } catch (_) {
      if (mounted) appToast("تعذر تحديد موقعك — تحقق من الصلاحية ثم حاول مجدداً");
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  bool get _hasFilters =>
      _area.isNotEmpty || _classification.isNotEmpty || _status.isNotEmpty || _q.trim().isNotEmpty || _custom.values.any((v) => v.isNotEmpty);

  void _clearFilters() {
    _area = "";
    _classification = "";
    _status = "";
    _q = "";
    _custom.clear();
    _searchController.clear();
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    if (_notFound) {
      return PageScaffold(
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("🧭", style: TextStyle(fontSize: 48)),
              SizedBox(height: 16),
              Text("القسم غير موجود", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: C.slate800)),
            ],
          ),
        ),
      );
    }
    if (_meta == null) {
      return PageScaffold(body: const PageLoader());
    }
    final sec = Section.fromJson(_meta!["section"] as Map<String, dynamic>);
    final classifications = (_meta!["classifications"] as List)
        .map((e) => Classification.fromJson(e as Map<String, dynamic>))
        .toList();
    final filters = (_meta!["filters"] as List)
        .map((e) => SectionFilter.fromJson(e as Map<String, dynamic>))
        .toList();
    final areas = (_meta!["areas"] as List).map((e) => Area.fromJson(e as Map<String, dynamic>)).toList();

    return PageScaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // العودة للرئيسية (نفس الويب)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => Navigator.of(context).pop(),
              child: Row(
                children: [
                  const Icon(Icons.arrow_forward, size: 15, color: C.emerald700),
                  const SizedBox(width: 6),
                  const Text("العودة للرئيسية", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.emerald700)),
                ],
              ),
            ),
          ),
          // رأس القسم
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: hexColor(sec.color, opacity: 10),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6)],
                ),
                child: Center(child: Text(sec.icon, style: const TextStyle(fontSize: 28))),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sec.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: C.slate900)),
                    const SizedBox(height: 2),
                    Text(
                      sec.description ?? "",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13, color: C.slate500),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: C.slate200),
                ),
                child: Text(
                  _loading ? "..." : "${_services.length} خدمة",
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: C.slate700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          // شريط الفلاتر
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: C.slate200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.only(right: 12, left: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: C.slate200),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.search, size: 16, color: C.slate400),
                            const SizedBox(width: 8),
                            Expanded(
                              child: TextField(
                                controller: _searchController,
                                onChanged: _onSearchChanged,
                                style: const TextStyle(fontSize: 14),
                                decoration: const InputDecoration(
                                  isCollapsed: true,
                                  border: InputBorder.none,
                                  hintText: "ابحث باسم الخدمة أو العنوان...",
                                  hintStyle: TextStyle(fontSize: 14, color: C.slate400),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _GeoButton(active: _pos != null, locating: _locating, onTap: _locate),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    _FilterSelect(
                      value: _area,
                      hint: "كل المناطق",
                      items: areas.map((a) => MapEntry(a.id.toString(), a.name)).toList(),
                      onChanged: (v) {
                        _area = v ?? "";
                        _reload();
                      },
                    ),
                    if (classifications.isNotEmpty)
                      _FilterSelect(
                        value: _classification,
                        hint: "كل التصنيفات",
                        items: classifications.map((c) => MapEntry(c.id.toString(), c.name)).toList(),
                        onChanged: (v) {
                          _classification = v ?? "";
                          _reload();
                        },
                      ),
                    _StatusSegment(
                      value: _status,
                      onChanged: (v) {
                        _status = v;
                        _reload();
                      },
                    ),
                    for (final f in filters)
                      _CustomFilter(
                        name: f.name,
                        options: f.options,
                        selected: _custom[f.id] ?? "",
                        onPick: (v) {
                          if (_custom[f.id] == v) {
                            _custom[f.id] = "";
                          } else {
                            _custom[f.id] = v;
                          }
                          _reload();
                        },
                      ),
                    if (_hasFilters)
                      GestureDetector(
                        onTap: _clearFilters,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.refresh, size: 13, color: C.rose700),
                            const SizedBox(width: 4),
                            const Text("مسح الفلاتر", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.rose700)),
                          ],
                        ),
                      ),
                  ],
                ),
                if (_pos != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: C.emerald50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: C.emerald200),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.my_location, size: 14, color: C.emerald700),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "يتم عرض الخدمات مرتبة حسب البُعد عن موقعك الحالي",
                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.emerald700),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),
          // النتائج
          if (_loading)
            Column(children: List.generate(4, (_) => const Padding(padding: EdgeInsets.only(bottom: 16), child: SkeletonCard())))
          else if (_services.isEmpty)
            const EmptyState(emoji: "🔍", title: "لا توجد نتائج مطابقة", subtitle: "جرب تغيير الفلاتر أو مسحها بالكامل")
          else
            Column(
              children: _services
                  .map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: ServiceCard(
                          service: s,
                          showDistance: _pos != null,
                          onTap: () => Navigator.of(context)
                              .push(MaterialPageRoute(builder: (_) => DetailScreen(slug: s.sectionSlug ?? widget.slug, id: s.id))),
                        ),
                      ))
                  .toList(),
            ),
        ],
      ),
    );
  }
}

class _GeoButton extends StatelessWidget {
  final bool active;
  final bool locating;
  final VoidCallback onTap;

  const _GeoButton({required this.active, required this.locating, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? C.emerald600 : C.slate100,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              locating
                  ? const SizedBox(
                      width: 15,
                      height: 15,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Icon(Icons.location_on, size: 15, color: active ? Colors.white : C.slate600),
              const SizedBox(width: 6),
              Text(
                active ? "عرض الأقرب إليك" : "القريبون مني",
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: active ? Colors.white : C.slate600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FilterSelect extends StatelessWidget {
  final String? value;
  final String hint;
  final List<MapEntry<String, String>> items;
  final ValueChanged<String?> onChanged;

  const _FilterSelect({required this.value, required this.hint, required this.items, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: C.slate50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: C.slate200),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isDense: true,
          isExpanded: false,
          hint: Text(hint, style: const TextStyle(fontSize: 13, color: C.slate500)),
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.circular(12),
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: C.slate700),
          items: items
              .map((e) => DropdownMenuItem<String>(
                    value: e.key,
                    child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 180), child: Text(e.value, overflow: TextOverflow.ellipsis)),
                  ))
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}

class _StatusSegment extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;

  const _StatusSegment({required this.value, required this.onChanged});

  static const _opts = [
    MapEntry("", "الكل"),
    MapEntry("open", "مفتوح الآن"),
    MapEntry("duty", "مناوبة"),
    MapEntry("closed", "مغلق"),
  ];

  Color _activeColor(String v) {
    switch (v) {
      case "open":
        return C.emerald600;
      case "duty":
        return C.amber500;
      case "closed":
        return C.rose500;
      default:
        return C.slate800;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: C.slate50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: C.slate200),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: _opts.map((o) {
          final active = value == o.key;
          return GestureDetector(
            onTap: () => onChanged(o.key),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: active ? _activeColor(o.key) : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                o.value,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: active ? Colors.white : C.slate500,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _CustomFilter extends StatelessWidget {
  final String name;
  final List<String> options;
  final String selected;
  final ValueChanged<String> onPick;

  const _CustomFilter({required this.name, required this.options, required this.selected, required this.onPick});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.slate400)),
        const SizedBox(width: 6),
        ...options.map((op) {
          final active = selected == op;
          return GestureDetector(
            onTap: () => onPick(op),
            child: Container(
              margin: const EdgeInsets.only(right: 4),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: active ? C.emerald600 : C.slate100,
                borderRadius: BorderRadius.circular(999),
                boxShadow: active ? [BoxShadow(color: C.emerald600.withValues(alpha: 0.3), blurRadius: 6, offset: const Offset(0, 2))] : null,
              ),
              child: Text(
                op,
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: active ? Colors.white : C.slate600),
              ),
            ),
          );
        }),
      ],
    );
  }
}
