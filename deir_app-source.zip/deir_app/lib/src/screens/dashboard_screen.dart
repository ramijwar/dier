import 'package:flutter/material.dart';
import '../models.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../dialogs/service_form_sheet.dart';

/// لوحة الخدمات (المملوك) — مطابقة للويب: حالة فورية + تعديل + حذف.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final session = Session.instance;
  List<Service> _services = [];
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    if (session.user == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => Navigator.of(context).pushNamedAndRemoveUntil("/login", (e) => false));
    } else {
      _load();
    }
  }

  Future<void> _load() async {
    try {
      final list = await session.api.myServices();
      if (mounted) setState(() => _services = list);
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _ready = true);
    }
  }

  Future<void> _toggleStatus(Service s, String status) async {
    if (s.status == status) return;
    setState(() {
      final i = _services.indexWhere((x) => x.id == s.id);
      if (i >= 0) _services[i] = _cloneWithStatus(s, status);
    });
    try {
      await session.api.setServiceStatus(s.id, status);
    } catch (e) {
      setState(() {
        final i = _services.indexWhere((x) => x.id == s.id);
        if (i >= 0) _services[i] = _cloneWithStatus(s, s.status);
      });
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    }
  }

  Service _cloneWithStatus(Service s, String status) => Service(
        id: s.id,
        name: s.name,
        description: s.description,
        phone: s.phone,
        address: s.address,
        lat: s.lat,
        lng: s.lng,
        status: status,
        isActive: s.isActive,
        rejected: s.rejected,
        sectionId: s.sectionId,
        areaId: s.areaId,
        classificationId: s.classificationId,
        sectionName: s.sectionName,
        sectionSlug: s.sectionSlug,
        sectionIcon: s.sectionIcon,
        sectionColor: s.sectionColor,
        areaName: s.areaName,
        classificationName: s.classificationName,
        ownerId: s.ownerId,
        filterValues: s.filterValues,
        hours: s.hours,
        createdAt: s.createdAt,
      );

  Future<void> _confirmDelete(Service s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("حذف الخدمة", style: TextStyle(fontWeight: FontWeight.w700)),
        content: Text("هل أنت متأكد من حذف «${s.name}»؟ لا يمكن التراجع عن هذا الإجراء."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("إلغاء")),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("حذف", style: TextStyle(color: C.rose700, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await session.api.deleteService(s.id);
      if (mounted) {
        setState(() => _services.removeWhere((x) => x.id == s.id));
        appToast("تم حذف الخدمة", success: true);
      }
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    }
  }

  Future<void> _openForm({Service? edit}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ServiceFormSheet(service: edit),
    );
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final user = session.user;
    return PageScaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("لوحة الخدمات", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: C.slate900)),
                    SizedBox(height: 2),
                  ],
                ),
              ),
              Material(
                color: C.emerald600,
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => _openForm(),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add, size: 16, color: Colors.white),
                        SizedBox(width: 6),
                        Text("إضافة خدمة", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          if (user != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                "مرحباً ${user.name} — أدر خدماتك: الحالة، أوقات الدوام، والفلاتر",
                style: const TextStyle(fontSize: 13, color: C.slate500),
              ),
            ),
          const SizedBox(height: 20),
          if (!_ready)
            const PageLoader()
          else if (_services.isEmpty)
            const _Empty()
          else
            Column(
              children: _services
                  .map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: _ServiceRow(
                          service: s,
                          onEdit: () => _openForm(edit: s),
                          onDelete: () => _confirmDelete(s),
                          onStatus: (st) => _toggleStatus(s, st),
                        ),
                      ))
                  .toList(),
            ),
        ],
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 56, horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.slate300),
      ),
      child: Column(
        children: [
          const Text("🏪", style: TextStyle(fontSize: 40)),
          const SizedBox(height: 12),
          const Text("لا تملك أي خدمة بعد", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.slate700)),
          const SizedBox(height: 4),
          const Text("أضف خدمتك الأولى وسيتم عرضها بعد موافقة الإدارة", style: TextStyle(fontSize: 14, color: C.slate500)),
          const SizedBox(height: 20),
          Material(
            color: C.emerald600,
            borderRadius: BorderRadius.circular(10),
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => Navigator.of(context).pop(),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.add, size: 16, color: Colors.white),
                    SizedBox(width: 6),
                    Text("أضف خدمتك الآن", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ServiceRow extends StatelessWidget {
  final Service service;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<String> onStatus;

  const _ServiceRow({
    required this.service,
    required this.onEdit,
    required this.onDelete,
    required this.onStatus,
  });

  @override
  Widget build(BuildContext context) {
    final s = service;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.slate200),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: hexColor(s.sectionColor ?? "#10b981", opacity: 10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(child: Text(s.sectionIcon ?? "🏪", style: const TextStyle(fontSize: 22))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: C.slate900)),
                        ),
                        const SizedBox(width: 8),
                        _StateBadge(s),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      [
                        if (s.sectionName != null) s.sectionName,
                        if (s.areaName != null) s.areaName,
                        if (s.classificationName != null) s.classificationName,
                      ].join(" · "),
                      style: const TextStyle(fontSize: 12, color: C.slate500),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                tooltip: "تعديل",
                icon: const Icon(Icons.edit_outlined, size: 18, color: C.slate600),
                onPressed: onEdit,
              ),
              IconButton(
                tooltip: "حذف",
                icon: const Icon(Icons.delete_outline, size: 18, color: C.rose700),
                onPressed: onDelete,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(height: 1, color: C.slate100),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text("الحالة الآن:", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: C.slate500)),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: C.slate50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: C.slate200),
                  ),
                  child: Row(
                    children: ["open", "duty", "closed"].map((st) {
                      final m = statusMeta[st]!;
                      final active = s.status == st;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => onStatus(st),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            decoration: BoxDecoration(
                              color: active ? m.solid : Colors.transparent,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Center(
                              child: Text(
                                m.label,
                                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: active ? Colors.white : C.slate500),
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StateBadge extends StatelessWidget {
  final Service s;

  const _StateBadge(this.s);

  @override
  Widget build(BuildContext context) {
    final (bg, fg, border, label) = s.isActive == 1
        ? (C.emerald50, C.emerald700, C.emerald200, "منشورة")
        : (s.rejected == 1
            ? (C.rose50, C.rose700, C.rose200, "مرفوضة — أعد الإرسال")
            : (C.amber50, C.amber700, C.amber200, "قيد المراجعة"));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: border),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg)),
    );
  }
}
