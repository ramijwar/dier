import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/status_badge.dart';

/// تفاصيل الخدمة — مطابقة للويب: شريط علوي بلون القسم + أوقات دوام + نبذة.
class DetailScreen extends StatefulWidget {
  final String slug;
  final int id;

  const DetailScreen({super.key, required this.slug, required this.id});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  Service? _service;
  bool _notFound = false;
  final session = Session.instance;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await session.api.service(widget.id);
      if (mounted) setState(() => _service = s);
    } catch (_) {
      if (mounted) setState(() => _notFound = true);
    }
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      appToast("تعذر فتح الرابط");
    }
  }

  AppBar _backAppBar(String label) {
    return AppBar(
      backgroundColor: C.slate50,
      elevation: 0,
      leading: TextButton(
        onPressed: () => Navigator.of(context).pop(),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.arrow_forward, size: 18, color: C.emerald700),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.emerald700)),
          ],
        ),
      ),
      titleSpacing: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_notFound) {
      return Scaffold(
        backgroundColor: C.slate50,
        appBar: _backAppBar("العودة"),
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("🔎", style: TextStyle(fontSize: 48)),
              SizedBox(height: 16),
              Text("الخدمة غير موجودة", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: C.slate800)),
            ],
          ),
        ),
      );
    }

    final s = _service;
    if (s == null) {
      return Scaffold(
        backgroundColor: C.slate50,
        appBar: _backAppBar("العودة"),
        body: const PageLoader(),
      );
    }

    final isOwner = session.user != null && s.ownerId != null && s.ownerId == session.user!.id;
    final today = todayIndex();
    final filterEntries = s.filterValues.entries.toList();
    final addressLine = [
      if (s.areaName != null && s.areaName!.isNotEmpty) s.areaName,
      if (s.address != null && s.address!.isNotEmpty) s.address,
    ].join("، ");

    return Scaffold(
      backgroundColor: C.slate50,
      appBar: _backAppBar("العودة إلى ${s.sectionName ?? "القسم"}"),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildMainCard(s, addressLine),
          const SizedBox(height: 16),
          _buildHoursCard(s, today),
          const SizedBox(height: 16),
          _buildAboutCard(s, filterEntries, isOwner),
        ],
      ),
    );
  }

  Widget _buildMainCard(Service s, String addressLine) {
    final color = hexColor(s.sectionColor ?? "#10b981");
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: C.slate200),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(height: 8, color: color),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: hexColor(s.sectionColor ?? "#10b981", opacity: 10),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Center(child: Text(s.sectionIcon ?? "🏪", style: const TextStyle(fontSize: 32))),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: C.slate900)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 6,
                            runSpacing: 6,
                            children: [
                              StatusBadge(status: s.status),
                              if (s.classificationName != null)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(color: C.slate100, borderRadius: BorderRadius.circular(999)),
                                  child: Text(s.classificationName!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate700)),
                                ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(color: C.slate200),
                                ),
                                child: Text(s.sectionName ?? "", style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate700)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    if (s.phone != null && s.phone!.isNotEmpty)
                      _ActionButton(
                        icon: Icons.call,
                        label: s.phone!,
                        primary: true,
                        ltrLabel: true,
                        onTap: () => _open("tel:${s.phone}"),
                      ),
                    if (s.lat != null && s.lng != null) ...[
                      const SizedBox(width: 8),
                      _ActionButton(
                        icon: Icons.map_outlined,
                        label: "الخريطة",
                        primary: false,
                        onTap: () => _open("https://www.google.com/maps?q=${s.lat},${s.lng}"),
                      ),
                    ],
                  ],
                ),
                if (addressLine.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.place, size: 15, color: C.emerald600),
                      const SizedBox(width: 6),
                      Expanded(child: Text(addressLine, style: const TextStyle(fontSize: 14, color: C.slate600))),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHoursCard(Service s, int today) {
    return _Card(
      title: "أوقات الدوام",
      icon: Icons.access_time,
      child: Column(
        children: [
          for (final h in s.hours)
            Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: h.day == today ? C.emerald50.withValues(alpha: 0.7) : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
                border: h.day == today ? Border.all(color: C.emerald200) : Border.all(color: Colors.transparent),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        Text(
                          kDays[h.day],
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: h.day == today ? FontWeight.w800 : FontWeight.w600,
                            color: h.day == today ? C.emerald700 : C.slate700,
                          ),
                        ),
                        if (h.day == today)
                          const Padding(
                            padding: EdgeInsets.only(right: 8),
                            child: Text("اليوم", style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: C.emerald600)),
                          ),
                      ],
                    ),
                  ),
                  if (h.isOpen)
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        "${h.openTime ?? "09:00"} — ${h.closeTime ?? "17:00"}",
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: C.slate800),
                      ),
                    )
                  else
                    const Text("مغلق", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: C.rose500)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAboutCard(Service s, List<MapEntry<String, String>> filterEntries, bool isOwner) {
    return _Card(
      title: "نبذة",
      icon: Icons.info_outline,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            s.description?.isNotEmpty == true ? s.description! : "لا توجد نبذة عن هذه الخدمة بعد.",
            style: const TextStyle(fontSize: 14, height: 1.6, color: C.slate600),
          ),
          if (filterEntries.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text("مواصفات الخدمة", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.slate400)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: filterEntries.map((e) {
                final yes = e.value == "yes";
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: yes ? C.emerald50 : C.slate100,
                    borderRadius: BorderRadius.circular(999),
                    border: yes ? Border.all(color: C.emerald200) : null,
                  ),
                  child: Text(
                    "${e.key}: ${e.value}",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: yes ? C.emerald700 : C.slate500),
                  ),
                );
              }).toList(),
            ),
          ],
          if (isOwner) ...[
            const SizedBox(height: 16),
            Material(
              color: C.emerald50,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => Navigator.of(context).pushNamed("/dashboard"),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.settings, size: 15, color: C.emerald700),
                      const SizedBox(width: 8),
                      const Text("هذه خدمتك — عدّلها من لوحة التحكم", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.emerald700)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _Card({required this.title, required this.icon, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.slate200),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 18, color: C.emerald600),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: C.slate900)),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool primary;
  final bool ltrLabel;
  final VoidCallback onTap;

  const _ActionButton({required this.icon, required this.label, required this.primary, required this.onTap, this.ltrLabel = false});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: primary ? C.emerald600 : Colors.white,
      borderRadius: BorderRadius.circular(10),
      shadowColor: primary ? C.emerald600.withValues(alpha: 0.3) : Colors.black.withValues(alpha: 0.08),
      elevation: primary ? 2 : 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
          decoration: primary ? null : BoxDecoration(border: Border.all(color: C.slate200), borderRadius: BorderRadius.circular(10)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: primary ? Colors.white : C.emerald600),
              const SizedBox(width: 6),
              if (ltrLabel)
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white)),
                )
              else
                Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.slate700)),
            ],
          ),
        ),
      ),
    );
  }
}
