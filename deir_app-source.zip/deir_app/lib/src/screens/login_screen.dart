import 'package:flutter/material.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// تسجيل الدخول — مطابقة للويب.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  final session = Session.instance;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final data = await session.api.login(email: _email.text.trim(), password: _password.text);
      await session.onLogin(data);
      appToast("تم تسجيل الدخول بنجاح", success: true);
      if (mounted) {
        final isAdmin = (data["user"] as Map<String, dynamic>)["role"] == "admin";
        Navigator.of(context).pushNamedAndRemoveUntil(isAdmin ? "/" : "/dashboard", (e) => false);
      }
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.slate50,
      appBar: AppBar(
        backgroundColor: C.slate50,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward, color: C.slate600),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: C.slate200),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [C.emerald500, C.teal600],
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(16)),
                      boxShadow: [BoxShadow(color: Color(0x40059669), blurRadius: 12, offset: Offset(0, 4))],
                    ),
                    child: Center(child: Text("د", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white))),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(child: Text("تسجيل الدخول", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: C.slate900))),
                const Center(child: Text("ادخل إلى لوحة إدارة خدماتك", style: TextStyle(fontSize: 14, color: C.slate500))),
                const SizedBox(height: 24),
                _Field(controller: _email, label: "البريد الإلكتروني", hint: "you@example.com", ltr: true, keyboard: TextInputType.emailAddress),
                const SizedBox(height: 14),
                _Field(controller: _password, label: "كلمة المرور", hint: "••••••••", password: true, ltr: true),
                const SizedBox(height: 20),
                _SubmitButton(label: "دخول", icon: Icons.login, busy: _busy, onTap: _submit),
                const SizedBox(height: 16),
                InkWell(
                  onTap: () => Navigator.of(context).pushNamed("/register"),
                  child: const Center(
                    child: Text(
                      "ليس لديك حساب؟ سجّل الآن",
                      style: TextStyle(fontSize: 14, color: C.slate500),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // الحسابات التجريبية
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: C.slate50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: C.slate200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text("حسابات تجريبية:", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.slate600)),
                      SizedBox(height: 6),
                      Row(children: [
                        Text("مشرف: ", style: TextStyle(fontSize: 12, color: C.slate500)),
                        Expanded(
                          child: Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text("admin@deir.app / admin123", textAlign: TextAlign.right, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate700)),
                          ),
                        ),
                      ]),
                      SizedBox(height: 2),
                      Row(children: [
                        Text("مملوك: ", style: TextStyle(fontSize: 12, color: C.slate500)),
                        Expanded(
                          child: Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text("owner@deir.app / owner123", textAlign: TextAlign.right, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate700)),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final bool password;
  final bool ltr;
  final TextInputType? keyboard;

  const _Field({
    required this.controller,
    required this.label,
    required this.hint,
    this.password = false,
    this.ltr = false,
    this.keyboard,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.slate700)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: C.slate200),
          ),
          child: Directionality(
            textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
            child: TextField(
              controller: controller,
              obscureText: password,
              keyboardType: keyboard,
              textAlign: ltr ? TextAlign.left : TextAlign.right,
              style: const TextStyle(fontSize: 14),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(fontSize: 14, color: C.slate400),
                isCollapsed: false,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                border: InputBorder.none,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _SubmitButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool busy;
  final VoidCallback onTap;

  const _SubmitButton({required this.label, required this.icon, required this.busy, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: C.emerald600,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: busy ? null : onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 13),
          child: Center(
            child: busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, size: 16, color: Colors.white),
                      const SizedBox(width: 8),
                      Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white)),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
