import 'package:flutter/material.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// إنشاء حساب — مطابقة للويب.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _busy = false;
  final session = Session.instance;

  @override
  void dispose() {
    for (final c in [_name, _phone, _email, _password, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (_password.text != _confirm.text) {
      appToast("كلمتا المرور غير متطابقتين");
      return;
    }
    setState(() => _busy = true);
    try {
      final data = await session.api.register(
        name: _name.text.trim(),
        email: _email.text.trim(),
        password: _password.text,
        phone: _phone.text.trim(),
      );
      await session.onLogin(data);
      appToast("تم إنشاء حسابك — أهلاً بك في خدمات الدير", success: true);
      if (mounted) Navigator.of(context).pushNamedAndRemoveUntil("/dashboard", (e) => false);
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.slate50,
      appBar: AppBar(
        backgroundColor: C.slate50,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward, color: C.slate600),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: C.slate200),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [C.emerald500, C.teal600],
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(16)),
                      boxShadow: [BoxShadow(color: Color(0x40059669), blurRadius: 12, offset: Offset(0, 4))],
                    ),
                    child: Center(child: Text("د", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white))),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(child: Text("إنشاء حساب جديد", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: C.slate900))),
                const Center(child: Text("سجّل حسابك ثم أضف خدمتك لتظهر للمواطنين", style: TextStyle(fontSize: 14, color: C.slate500))),
                const SizedBox(height: 24),
                _Field(controller: _name, label: "الاسم الكامل *", hint: "مثال: محمد أحمد"),
                const SizedBox(height: 14),
                _Field(controller: _phone, label: "رقم الهاتف", hint: "09xx xxx xxx", ltr: true, keyboard: TextInputType.phone),
                const SizedBox(height: 14),
                _Field(controller: _email, label: "البريد الإلكتروني *", hint: "you@example.com", ltr: true, keyboard: TextInputType.emailAddress),
                const SizedBox(height: 14),
                _Field(controller: _password, label: "كلمة المرور *", hint: "••••••••", password: true, ltr: true),
                const SizedBox(height: 14),
                _Field(controller: _confirm, label: "تأكيد كلمة المرور *", hint: "••••••••", password: true, ltr: true),
                const SizedBox(height: 20),
                Material(
                  color: C.emerald600,
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: _busy ? null : _submit,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      child: Center(
                        child: _busy
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.person_add_alt_1, size: 16, color: Colors.white),
                                  SizedBox(width: 8),
                                  Text("إنشاء الحساب", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white)),
                                ],
                              ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                InkWell(
                  onTap: () => Navigator.of(context).pushNamed("/login"),
                  child: const Center(
                    child: Text(
                      "لديك حساب؟ سجل دخولك",
                      style: TextStyle(fontSize: 14, color: C.slate500),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final bool password;
  final bool ltr;
  final TextInputType? keyboard;

  const _Field({
    required this.controller,
    required this.label,
    required this.hint,
    this.password = false,
    this.ltr = false,
    this.keyboard,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.slate700)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: C.slate200),
          ),
          child: Directionality(
            textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
            child: TextField(
              controller: controller,
              obscureText: password,
              keyboardType: keyboard,
              textAlign: ltr ? TextAlign.left : TextAlign.right,
              style: const TextStyle(fontSize: 14),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(fontSize: 14, color: C.slate400),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                border: InputBorder.none,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
