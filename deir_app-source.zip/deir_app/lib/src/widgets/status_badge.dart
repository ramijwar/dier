import 'package:flutter/material.dart';
import '../theme.dart';

/// شارة الحالة — مطابقة للويب: حبة نابضة (للمفتوح) + نص بلون القسم.
class StatusBadge extends StatefulWidget {
  final String status; // open | duty | closed

  const StatusBadge({super.key, required this.status});

  @override
  State<StatusBadge> createState() => _StatusBadgeState();
}

class _StatusBadgeState extends State<StatusBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1200),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = statusMeta[widget.status] ?? statusMeta["closed"]!;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: m.bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: m.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (context, _) => Opacity(
              opacity: widget.status == "open" ? 0.35 + 0.65 * _pulse.value : 1,
              child: Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(color: m.dot, shape: BoxShape.circle),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Text(m.label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: m.text)),
        ],
      ),
    );
  }
}
