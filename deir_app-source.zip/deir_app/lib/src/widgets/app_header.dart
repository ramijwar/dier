import 'package:flutter/material.dart';
import '../config.dart';
import '../session.dart';
import '../theme.dart';

/// ترويسة التطبيق — مطابقة للويب: شعار + اسم + (ضيف: أضف خدمتك | مستخدم: قائمة).
class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final session = Session.instance;
    return Container(
      height: 64,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: C.slate200, width: 1)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            // الشعار
            InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => Navigator.of(context).pushReplacementNamed("/"),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [C.emerald500, C.teal600],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: C.emerald600.withValues(alpha: 0.25), blurRadius: 8, offset: const Offset(0, 3)),
                  ],
                ),
                child: const Center(
                  child: Text("د", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(kAppName, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: C.slate900)),
                  Text(kAppRegion, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: C.slate500)),
                ],
              ),
            ),
            ListenableBuilder(
              listenable: session,
              builder: (context, _) => session.user == null
                  ? const _GuestActions()
                  : _UserMenu(session: session),
            ),
          ],
        ),
      ),
    );
  }
}

class _GuestActions extends StatelessWidget {
  const _GuestActions();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 2),
      child: Row(
        children: [
          TextButton(
            onPressed: () => Navigator.of(context).pushNamed("/login"),
            style: TextButton.styleFrom(
              foregroundColor: C.slate700,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              minimumSize: const Size(0, 36),
            ),
            child: const Text("تسجيل الدخول", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
          const SizedBox(width: 8),
          _EmberButton(
            label: "أضف خدمتك",
            icon: Icons.person_add_alt_1,
            onTap: () => Navigator.of(context).pushNamed("/register"),
          ),
        ],
      ),
    );
  }
}

class _UserMenu extends StatelessWidget {
  final Session session;

  const _UserMenu({required this.session});

  @override
  Widget build(BuildContext context) {
    final u = session.user!;
    return PopupMenuButton<String>(
      tooltip: null,
      onSelected: (v) {
        if (v == "dashboard") {
          Navigator.of(context).pushNamed("/dashboard");
        } else if (v == "logout") {
          session.logout();
          Navigator.of(context).pushNamedAndRemoveUntil("/", (e) => false);
        }
      },
      position: PopupMenuPosition.under,
      offset: const Offset(0, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: C.slate200),
      ),
      color: Colors.white,
      itemBuilder: (context) => [
        PopupMenuItem<String>(
          enabled: false,
          height: 64,
          child: const _MenuHeader(),
        ),
        const PopupMenuItem<String>(value: "dashboard", child: _MenuRow(icon: Icons.dashboard_outlined, label: "لوحة الخدمات")),
        const PopupMenuItem<String>(
          value: "logout",
          height: 44,
          child: _MenuRow(icon: Icons.logout, label: "تسجيل الخروج", danger: true),
        ),
      ],
      child: Container(
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: C.slate200),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(color: C.emerald100, shape: BoxShape.circle),
              child: Center(
                child: Text(
                  u.name.isNotEmpty ? u.name[0] : "؟",
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: C.emerald700),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 100),
              child: Text(
                u.name.split(" ").first,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.slate700),
              ),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.keyboard_arrow_down, size: 18, color: C.slate400),
          ],
        ),
      ),
    );
  }
}

class _MenuHeader extends StatelessWidget {
  const _MenuHeader();

  @override
  Widget build(BuildContext context) {
    final u = Session.instance.user!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(u.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: C.slate900)),
        Text(u.email, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: C.slate500)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(color: C.emerald50, borderRadius: BorderRadius.circular(999)),
          child: Text(
            u.role == "admin" ? "مشرف النظام" : "مملوك خدمة",
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: C.emerald700),
          ),
        ),
      ],
    );
  }
}

class _MenuRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool danger;

  const _MenuRow({required this.icon, required this.label, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final color = danger ? C.rose700 : C.slate700;
    return Row(
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(fontSize: 14, color: color, fontWeight: FontWeight.w500)),
      ],
    );
  }
}

class _EmberButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _EmberButton({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: C.emerald600,
      borderRadius: BorderRadius.circular(10),
      elevation: 2,
      shadowColor: C.emerald600.withValues(alpha: 0.3),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: Colors.white),
              const SizedBox(width: 6),
              Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }
}
