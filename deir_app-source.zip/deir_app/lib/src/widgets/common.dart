import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../theme.dart';
import 'app_header.dart';

/// تنبيه علوي — بديل عن sonner في الويب.
void appToast(String message, {bool success = false, bool warning = false}) {
  final bg = success ? C.emerald600 : (warning ? C.amber500 : C.rose500);
  Fluttertoast.showToast(
    msg: message,
    gravity: ToastGravity.TOP,
    toastLength: Toast.LENGTH_LONG,
    backgroundColor: bg,
    textColor: Colors.white,
    fontSize: 14,
  );
}

/// هيكل تحميل — مثل Skeleton في الويب.
class SkeletonCard extends StatelessWidget {
  const SkeletonCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 176,
      decoration: BoxDecoration(
        color: C.slate100,
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }
}

class PageLoader extends StatelessWidget {
  const PageLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(48),
        child: SizedBox(
          width: 32,
          height: 32,
          child: CircularProgressIndicator(strokeWidth: 3, color: C.emerald600),
        ),
      ),
    );
  }
}

/// حالة فارغة — مطابقة للويب.
class EmptyState extends StatelessWidget {
  final String emoji;
  final String title;
  final String? subtitle;

  const EmptyState({super.key, required this.emoji, required this.title, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 64, horizontal: 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.slate300, style: BorderStyle.solid),
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 40)),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.slate700)),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle!, style: const TextStyle(fontSize: 14, color: C.slate500)),
          ],
        ],
      ),
    );
  }
}

/// غلاف صفحة: ترويسة (ممتدة خلف شريط الحالة بلون أبيض) + محتوى قابل للتمرير.
class PageScaffold extends StatelessWidget {
  final Widget body;

  const PageScaffold({super.key, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.slate50,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            child: const AppHeader(),
          ),
          Expanded(child: body),
        ],
      ),
    );
  }
}
