import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';
import 'status_badge.dart';

/// بطاقة خدمة — مطابقة للويب: أيقونة + اسم + منطقة · تصنيف
/// + شارة الحالة + شارات الفلاتر + هاتف + مسافة (عند تفعيل الموقع).
class ServiceCard extends StatelessWidget {
  final Service service;
  final bool showDistance;
  final VoidCallback onTap;

  const ServiceCard({super.key, required this.service, this.showDistance = false, required this.onTap});

  String? formatDistance(double? km) {
    if (km == null) return null;
    if (km < 1) {
      final m = (km * 1000).round() ~/ 10 * 10;
      return "${m < 10 ? 10 : m} م";
    }
    return "${km.toStringAsFixed(1)} كم";
  }

  @override
  Widget build(BuildContext context) {
    final s = service;
    final yesValues = s.filterValues.entries.where((e) => e.value == "yes").map((e) => e.key).take(3).toList();

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: C.slate200),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: hexColor(s.sectionColor ?? "#10b981", opacity: 10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(child: Text(s.sectionIcon ?? "🏪", style: const TextStyle(fontSize: 20))),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        s.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.slate900),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          const Icon(Icons.place, size: 12, color: C.slate400),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              [if (s.areaName != null) s.areaName, if (s.classificationName != null) s.classificationName]
                                  .where((e) => e != null && e.isNotEmpty)
                                  .join(" · ")
                                  .isEmpty
                                  ? "—"
                                  : [
                                      if (s.areaName != null) s.areaName,
                                      if (s.classificationName != null) s.classificationName,
                                    ].where((e) => e != null && e.isNotEmpty).join(" · "),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12, color: C.slate500),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                StatusBadge(status: s.status),
              ],
            ),
            if (yesValues.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: yesValues
                    .map((v) => Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                          decoration: BoxDecoration(color: C.slate100, borderRadius: BorderRadius.circular(999)),
                          child: Text(v, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: C.slate600)),
                        ))
                    .toList(),
              ),
            ],
            const SizedBox(height: 12),
            Container(height: 1, color: C.slate100),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (s.phone != null && s.phone!.isNotEmpty)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.call, size: 14, color: C.emerald600),
                      const SizedBox(width: 6),
                      TextDirectionality(
                        textDirection: TextDirection.ltr,
                        child: Text(s.phone!, style: const TextStyle(fontSize: 14, color: C.slate600)),
                      ),
                    ],
                  )
                else
                  const Text("—", style: TextStyle(fontSize: 12, color: C.slate300)),
                showDistance && s.distanceKm != null
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.my_location, size: 14, color: C.emerald700),
                          const SizedBox(width: 4),
                          Text(
                            formatDistance(s.distanceKm)!,
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: C.emerald700),
                          ),
                        ],
                      )
                    : const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("التفاصيل", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.emerald700)),
                          SizedBox(width: 4),
                          Text("←", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.emerald700)),
                        ],
                      ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class TextDirectionality extends StatelessWidget {
  final Widget child;
  final TextDirection textDirection;

  const TextDirectionality({super.key, required this.child, required this.textDirection});

  @override
  Widget build(BuildContext context) => Directionality(textDirection: textDirection, child: child);
}
