/// نماذج البيانات — مطابقة للاستجابة الواردة من الـ API.
library;

class User {
  final int id;
  final String name;
  final String email;
  final String? phone;
  final String role; // admin | owner
  final String? createdAt;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.role,
    this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> j) => User(
        id: (j["id"] as num).toInt(),
        name: j["name"] as String,
        email: j["email"] as String,
        phone: j["phone"] as String?,
        role: (j["role"] as String?) ?? "owner",
        createdAt: j["created_at"] as String?,
      );
}

class Section {
  final int id;
  final String name;
  final String slug;
  final String icon;
  final String? description;
  final String color;
  final int? serviceCount;

  Section({
    required this.id,
    required this.name,
    required this.slug,
    required this.icon,
    this.description,
    required this.color,
    this.serviceCount,
  });

  factory Section.fromJson(Map<String, dynamic> j) => Section(
        id: (j["id"] as num).toInt(),
        name: j["name"] as String,
        slug: j["slug"] as String,
        icon: (j["icon"] as String?) ?? "🏪",
        description: j["description"] as String?,
        color: (j["color"] as String?) ?? "#10b981",
        serviceCount: (j["service_count"] as num?)?.toInt(),
      );
}

class Area {
  final int id;
  final String name;

  const Area({required this.id, required this.name});

  factory Area.fromJson(Map<String, dynamic> j) =>
      Area(id: (j["id"] as num).toInt(), name: j["name"] as String);
}

class Classification {
  final int id;
  final int sectionId;
  final String name;

  Classification({required this.id, required this.sectionId, required this.name});

  factory Classification.fromJson(Map<String, dynamic> j) => Classification(
        id: (j["id"] as num).toInt(),
        sectionId: (j["section_id"] as num).toInt(),
        name: j["name"] as String,
      );
}

class SectionFilter {
  final int id;
  final int sectionId;
  final String name;
  final List<String> options;

  SectionFilter({
    required this.id,
    required this.sectionId,
    required this.name,
    required this.options,
  });

  factory SectionFilter.fromJson(Map<String, dynamic> j) => SectionFilter(
        id: (j["id"] as num).toInt(),
        sectionId: (j["section_id"] as num).toInt(),
        name: j["name"] as String,
        options: (j["options"] as List<dynamic>? ?? [])
            .map((e) => e.toString())
            .toList(),
      );
}

class HourRow {
  final int day; // 0=الأحد .. 6=السبت
  final bool isOpen;
  final String? openTime;
  final String? closeTime;

  HourRow({
    required this.day,
    required this.isOpen,
    this.openTime,
    this.closeTime,
  });

  factory HourRow.fromJson(Map<String, dynamic> j) => HourRow(
        day: (j["day"] as num).toInt(),
        isOpen: (j["is_open"] as num?) == 1,
        openTime: j["open_time"] as String?,
        closeTime: j["close_time"] as String?,
      );

  Map<String, dynamic> toJson() => {
        "day": day,
        "is_open": isOpen ? 1 : 0,
        "open_time": isOpen ? (openTime ?? "09:00") : null,
        "close_time": isOpen ? (closeTime ?? "17:00") : null,
      };
}

class Service {
  final int id;
  final String name;
  final String? description;
  final String? phone;
  final String? address;
  final double? lat;
  final double? lng;
  final String status; // open | closed | duty
  final int? isActive;
  final int? rejected;
  final int sectionId;
  final int? areaId;
  final int? classificationId;
  final String? sectionName;
  final String? sectionSlug;
  final String? sectionIcon;
  final String? sectionColor;
  final String? areaName;
  final String? classificationName;
  final int? ownerId;
  final String? ownerName;
  final String? ownerEmail;
  final Map<String, String> filterValues;
  final List<HourRow> hours;
  final double? distanceKm;
  final String? createdAt;

  Service({
    required this.id,
    required this.name,
    this.description,
    this.phone,
    this.address,
    this.lat,
    this.lng,
    required this.status,
    this.isActive,
    this.rejected,
    required this.sectionId,
    this.areaId,
    this.classificationId,
    this.sectionName,
    this.sectionSlug,
    this.sectionIcon,
    this.sectionColor,
    this.areaName,
    this.classificationName,
    this.ownerId,
    this.ownerName,
    this.ownerEmail,
    this.filterValues = const {},
    this.hours = const [],
    this.distanceKm,
    this.createdAt,
  });

  factory Service.fromJson(Map<String, dynamic> j) => Service(
        id: (j["id"] as num).toInt(),
        name: j["name"] as String,
        description: j["description"] as String?,
        phone: j["phone"] as String?,
        address: j["address"] as String?,
        lat: (j["lat"] as num?)?.toDouble(),
        lng: (j["lng"] as num?)?.toDouble(),
        status: (j["status"] as String?) ?? "open",
        isActive: (j["is_active"] as num?)?.toInt(),
        rejected: (j["rejected"] as num?)?.toInt(),
        sectionId: (j["section_id"] as num).toInt(),
        areaId: (j["area_id"] as num?)?.toInt(),
        classificationId: (j["classification_id"] as num?)?.toInt(),
        sectionName: j["section_name"] as String?,
        sectionSlug: j["section_slug"] as String?,
        sectionIcon: j["section_icon"] as String?,
        sectionColor: j["section_color"] as String?,
        areaName: j["area_name"] as String?,
        classificationName: j["classification_name"] as String?,
        ownerId: (j["owner_id"] as num?)?.toInt(),
        ownerName: j["owner_name"] as String?,
        ownerEmail: j["owner_email"] as String?,
        filterValues: _parseFilterValues(j["filter_values"]),
        hours: ((j["hours"] as List<dynamic>? ?? [])
                .map((h) => HourRow.fromJson(h as Map<String, dynamic>))
                .toList()),
        distanceKm: (j["distance_km"] as num?)?.toDouble(),
        createdAt: j["created_at"] as String?,
      );

  /// الـ API يرسل filter_values قاموساً عند وجود قيم
  /// وقائمة فارغة [] عند عدم وجودها — نتعامل مع الحالتين.
  static Map<String, String> _parseFilterValues(dynamic raw) {
    final out = <String, String>{};
    if (raw is Map) {
      raw.forEach((k, v) => out[k.toString()] = v.toString());
    }
    return out;
  }
}
