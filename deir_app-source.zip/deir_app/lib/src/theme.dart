import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// لوحة الألوان — مطابقة لتطبيق الويب (Tailwind).
class C {
  // emerald
  static const Color emerald50 = Color(0xFFECFDF5);
  static const Color emerald100 = Color(0xFFD1FAE5);
  static const Color emerald200 = Color(0xFFA7F3D0);
  static const Color emerald300 = Color(0xFF6EE7B7);
  static const Color emerald500 = Color(0xFF10B981);
  static const Color emerald600 = Color(0xFF059669);
  static const Color emerald700 = Color(0xFF047857);

  // teal
  static const Color teal600 = Color(0xFF0D9488);
  static const Color teal700 = Color(0xFF0F766E);

  // slate
  static const Color slate50 = Color(0xFFF8FAFC);
  static const Color slate100 = Color(0xFFF1F5F9);
  static const Color slate200 = Color(0xFFE2E8F0);
  static const Color slate300 = Color(0xFFCBD5E1);
  static const Color slate400 = Color(0xFF94A3B8);
  static const Color slate500 = Color(0xFF64748B);
  static const Color slate600 = Color(0xFF475569);
  static const Color slate700 = Color(0xFF334155);
  static const Color slate800 = Color(0xFF1E293B);
  static const Color slate900 = Color(0xFF0F172A);

  // rose
  static const Color rose50 = Color(0xFFFFF1F2);
  static const Color rose200 = Color(0xFFFECDd3);
  static const Color rose500 = Color(0xFFF43F5E);
  static const Color rose700 = Color(0xFFBE123C);

  // amber
  static const Color amber50 = Color(0xFFFFFBE6);
  static const Color amber200 = Color(0xFFFDE68A);
  static const Color amber500 = Color(0xFFF59E0B);
  static const Color amber700 = Color(0xFFB45309);

  // sky / violet (مزايا الرئيسية)
  static const Color sky50 = Color(0xFFF0F9FF);
  static const Color sky600 = Color(0xFF0284C7);
  static const Color violet50 = Color(0xFFF5F3FF);
  static const Color violet600 = Color(0xFF7C3AED);
}

class StatusMeta {
  final String label;
  final Color bg;
  final Color text;
  final Color border;
  final Color dot;
  final Color solid;

  const StatusMeta(this.label, this.bg, this.text, this.border, this.dot, this.solid);
}

const Map<String, StatusMeta> statusMeta = {
  "open": StatusMeta("مفتوح الآن", C.emerald50, C.emerald700, C.emerald200, C.emerald500, C.emerald600),
  "duty": StatusMeta("مناوبة", C.amber50, C.amber700, C.amber200, C.amber500, C.amber500),
  "closed": StatusMeta("مغلق", C.rose50, C.rose700, C.rose200, C.rose500, C.rose500),
};

/// أسماء الأيام — 0=الأحد .. 6=السبت (نفس الويب).
const List<String> kDays = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

/// فهرس اليوم الحالي بنفس منطق JS getDay().
int todayIndex() => DateTime.now().weekday % 7;

ThemeData buildAppTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: C.emerald600,
      brightness: Brightness.light,
    ),
    scaffoldBackgroundColor: C.slate50,
  );
  return base.copyWith(
    textTheme: GoogleFonts.ibmPlexSansArabicTextTheme(base.textTheme),
    iconTheme: const IconThemeData(color: C.slate600),
    splashFactory: InkRipple.splashFactory,
  );
}

/// لون قسم بصيغة #RRGGBB مع شفافية hex (مثل ويب: color + "1a").
Color hexColor(String hex, {int? opacity}) {
  var h = hex.trim().replaceFirst("#", "");
  if (h.length == 6) h = "FF$h";
  final value = int.tryParse(h, radix: 16);
  if (value == null) return opacity != null ? C.slate200.withValues(alpha: opacity / 255) : C.slate200;
  final a = opacity ?? ((value >> 24) & 0xFF);
  return Color.fromRGBO((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF, a / 255);
}
