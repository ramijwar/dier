import 'package:flutter/material.dart';
import '../models.dart';
import '../session.dart';
import '../theme.dart';
import '../widgets/common.dart';

T? _find<T>(List<T> list, bool Function(T) test) {
  for (final e in list) {
    if (test(e)) return e;
  }
  return null;
}

/// نموذج إضافة/تعديل خدمة — مطابقة لحوار الويب (قائمة سفلية في الجوال).
class ServiceFormSheet extends StatefulWidget {
  final Service? service;

  const ServiceFormSheet({super.key, this.service});

  @override
  State<ServiceFormSheet> createState() => _ServiceFormSheetState();
}

class _ServiceFormSheetState extends State<ServiceFormSheet> {
  final session = Session.instance;

  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _description = TextEditingController();
  final _lat = TextEditingController();
  final _lng = TextEditingController();

  List<Section> _sections = [];
  List<Area> _areas = [];
  int? _sectionId;
  int? _areaId;
  int? _classifId;
  List<Classification> _classifs = [];
  List<SectionFilter> _filters = [];
  final Map<int, String> _filterValues = {};
  String _status = "open";
  late List<HourRow> _hours;
  bool _busy = false;

  bool get isEdit => widget.service != null;

  @override
  void initState() {
    super.initState();
    _hours = [
      for (int i = 0; i < 7; i++) HourRow(day: i, isOpen: i < 5, openTime: "09:00", closeTime: "17:00"),
    ];
    _loadBase();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initFromService());
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _address, _description, _lat, _lng]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadBase() async {
    try {
      final results = await Future.wait([session.api.sections(), session.api.sectionMeta("all")]);
      final meta = results[1] as Map<String, dynamic>;
      if (mounted) {
        setState(() {
          _sections = results[0] as List<Section>;
          _areas = (meta["areas"] as List).map((e) => Area.fromJson(e as Map<String, dynamic>)).toList();
        });
      }
    } catch (_) {}
  }

  void _initFromService() {
    final s = widget.service;
    if (s == null) return;
    _name.text = s.name;
    _phone.text = s.phone ?? "";
    _address.text = s.address ?? "";
    _description.text = s.description ?? "";
    _lat.text = s.lat?.toString() ?? "";
    _lng.text = s.lng?.toString() ?? "";
    _sectionId = s.sectionId;
    _areaId = s.areaId;
    _classifId = s.classificationId;
    _status = s.status;
    if (s.hours.length == 7) _hours = s.hours;
    s.filterValues.forEach((k, v) {
      // القيمة مفهرسة باسم الفلتر في الاستجابة
      final f = _find(_filters, (x) => x.name == k);
      if (f != null) _filterValues[f.id] = v;
    });
    _loadSectionMeta();
  }

  Future<void> _loadSectionMeta() async {
    final sec = _find(_sections, (s) => s.id == _sectionId);
    if (sec == null) {
      setState(() {
        _classifs = [];
        _filters = [];
      });
      return;
    }
    try {
      final meta = await session.api.sectionMeta(sec.slug);
      if (mounted) {
        setState(() {
          _classifs = (meta["classifications"] as List).map((e) => Classification.fromJson(e as Map<String, dynamic>)).toList();
          _filters = (meta["filters"] as List).map((e) => SectionFilter.fromJson(e as Map<String, dynamic>)).toList();
          // إعادة ربط قيم الفلاتر المحفوظة بالاسم
          final s = widget.service;
          if (s != null) {
            _filterValues.clear();
            s.filterValues.forEach((k, v) {
              final f = _find(_filters, (x) => x.name == k);
              if (f != null) _filterValues[f.id] = v;
            });
          }
        });
      }
    } catch (_) {}
  }

  void _onSectionChanged(int? id) {
    setState(() {
      _sectionId = id;
      _classifId = null;
      _filterValues.clear();
      _classifs = [];
      _filters = [];
    });
    _loadSectionMeta();
  }

  Future<void> _pickTime(HourRow h, bool isStart) async {
    final initial = TimeOfDay(
      hour: int.tryParse((isStart ? h.openTime : h.closeTime) ?? "") ?? (isStart ? 9 : 17),
      minute: 0,
    );
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked == null) return;
    final hh = picked.hour.toString().padLeft(2, "0");
    final mm = picked.minute.toString().padLeft(2, "0");
    final v = "$hh:$mm";
    setState(() {
      final i = _hours.indexWhere((x) => x.day == h.day);
      _hours[i] = HourRow(day: h.day, isOpen: h.isOpen, openTime: isStart ? v : h.openTime, closeTime: isStart ? h.closeTime : v);
    });
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (_name.text.trim().isEmpty) {
      appToast("أدخل اسم الخدمة");
      return;
    }
    if (_sectionId == null) {
      appToast("اختر قسماً للخدمة");
      return;
    }
    setState(() => _busy = true);
    try {
      final payload = {
        "name": _name.text.trim(),
        "section_id": _sectionId,
        "area_id": _areaId,
        "classification_id": _classifId,
        "phone": _phone.text.trim().isEmpty ? null : _phone.text.trim(),
        "address": _address.text.trim().isEmpty ? null : _address.text.trim(),
        "description": _description.text.trim().isEmpty ? null : _description.text.trim(),
        "lat": _lat.text.trim().isEmpty ? null : double.tryParse(_lat.text.trim()),
        "lng": _lng.text.trim().isEmpty ? null : double.tryParse(_lng.text.trim()),
        "status": _status,
        "hours": _hours.map((h) => h.toJson()).toList(),
        "filter_values": _filterValues.map((k, v) => MapEntry(k.toString(), v)),
      };
      final s = widget.service;
      if (s == null) {
        await session.api.createService(payload);
        appToast("تم إرسال خدمتك للمراجعة — ستظهر بعد موافقة الإدارة", success: true);
      } else {
        await session.api.updateService(s.id, payload);
        appToast("تم تحديث بيانات الخدمة", success: true);
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) appToast(e.toString().replaceFirst("Exception: ", ""));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.92,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, scrollController) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: ListView(
          controller: scrollController,
          padding: EdgeInsets.fromLTRB(20, 16, 20, MediaQuery.of(context).viewInsets.bottom + 24),
          children: [
            Center(
              child: Container(width: 40, height: 4, decoration: BoxDecoration(color: C.slate200, borderRadius: BorderRadius.circular(999))),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isEdit ? "تعديل الخدمة" : "إضافة خدمة جديدة",
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: C.slate900),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        isEdit
                            ? "عدّل بيانات خدمتك وأوقات الدوام — التغييرات تنعكس مباشرة"
                            : "ستُعرض خدمتك على المواطنين بعد موافقة الإدارة",
                        style: const TextStyle(fontSize: 13, color: C.slate500),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: C.slate400),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _Label("اسم الخدمة *"),
            _Box(_name, hint: "مثال: صيدلية الشفاء"),
            const SizedBox(height: 14),
            _Label("القسم *"),
            _SelectBox(
              value: _sectionId?.toString(),
              hint: "اختر القسم",
              items: _sections.map((x) => MapEntry(x.id.toString(), "${x.icon} ${x.name}")).toList(),
              onChanged: (v) => _onSectionChanged(v == null ? null : int.parse(v)),
            ),
            const SizedBox(height: 14),
            _Label("المنطقة"),
            _SelectBox(
              value: _areaId?.toString(),
              hint: "اختر المنطقة",
              items: _areas.map((a) => MapEntry(a.id.toString(), a.name)).toList(),
              onChanged: (v) => setState(() => _areaId = v == null ? null : int.parse(v)),
            ),
            if (_classifs.isNotEmpty) ...[
              const SizedBox(height: 14),
              _Label("التصنيف"),
              _SelectBox(
                value: _classifId?.toString(),
                hint: "اختر التصنيف",
                items: _classifs.map((c) => MapEntry(c.id.toString(), c.name)).toList(),
                onChanged: (v) => setState(() => _classifId = v == null ? null : int.parse(v)),
              ),
            ],
            const SizedBox(height: 14),
            _Label("رقم الهاتف"),
            _Box(_phone, hint: "09xx xxx xxx", ltr: true, keyboard: TextInputType.phone),
            const SizedBox(height: 14),
            _Label("العنوان"),
            _Box(_address, hint: "الشارع، الحي، أقرب معلم"),
            const SizedBox(height: 14),
            _Label("نبذة عن الخدمة"),
            Container(
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.slate200)),
              child: TextField(
                controller: _description,
                maxLines: 2,
                style: const TextStyle(fontSize: 14),
                decoration: const InputDecoration(
                  hintText: "وصف مختصر يظهر في صفحة الخدمة",
                  hintStyle: TextStyle(fontSize: 14, color: C.slate400),
                  contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: InputBorder.none,
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _Label("خط العرض (اختياري)"),
                      _Box(_lat, hint: "35.3337", ltr: true),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _Label("خط الطول (اختياري)"),
                      _Box(_lng, hint: "41.8178", ltr: true),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _Label("حالة الخدمة الآن"),
            Row(
              children: ["open", "duty", "closed"].map((st) {
                final m = statusMeta[st]!;
                final active = _status == st;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _status = st),
                    child: Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: active ? m.solid : Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: active ? m.solid : C.slate200),
                      ),
                      child: Center(
                        child: Text(m.label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: active ? Colors.white : C.slate500)),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            if (_filters.isNotEmpty) ...[
              const SizedBox(height: 14),
              _Label("فلاتر القسم"),
              for (final f in _filters) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text(f.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate500))),
                    SizedBox(
                      width: 120,
                      child: _SelectBox(
                        value: _filterValues[f.id],
                        hint: "—",
                        items: f.options.map((o) => MapEntry(o, o)).toList(),
                        onChanged: (v) => setState(() {
                          if (v == null) {
                            _filterValues.remove(f.id);
                          } else {
                            _filterValues[f.id] = v;
                          }
                        }),
                      ),
                    ),
                  ],
                ),
              ],
            ],
            const SizedBox(height: 14),
            _Label("أوقات الدوام"),
            for (final h in _hours)
              Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: C.slate50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: C.slate200),
                ),
                child: Row(
                  children: [
                    SizedBox(width: 64, child: Text(kDays[h.day], style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: C.slate700))),
                    Switch(
                      value: h.isOpen,
                      onChanged: (v) => setState(() {
                        final i = _hours.indexWhere((x) => x.day == h.day);
                        _hours[i] = HourRow(day: h.day, isOpen: v, openTime: h.openTime, closeTime: h.closeTime);
                      }),
                    ),
                    if (h.isOpen) ...[
                      _TimePill(label: h.openTime ?? "09:00", icon: Icons.play_arrow, onTap: () => _pickTime(h, true)),
                      const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text("إلى", style: TextStyle(fontSize: 12, color: C.slate400))),
                      _TimePill(label: h.closeTime ?? "17:00", icon: Icons.stop, onTap: () => _pickTime(h, false)),
                    ] else
                      const Text("مغلق", style: TextStyle(fontSize: 12, color: C.slate400)),
                  ],
                ),
              ),
            const SizedBox(height: 8),
            const Text("تظهر هذه الأوقات في صفحة الخدمة أمام الزوار.", style: TextStyle(fontSize: 11, color: C.slate400)),
            const SizedBox(height: 20),
            Material(
              color: C.emerald600,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: _busy ? null : _submit,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: Center(
                    child: _busy
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.save, size: 16, color: Colors.white),
                              const SizedBox(width: 8),
                              Text(
                                isEdit ? "حفظ التغييرات" : "إرسال الخدمة للمراجعة",
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;

  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.slate700)),
      );
}

class _Box extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final bool ltr;
  final TextInputType? keyboard;

  const _Box(this.controller, {required this.hint, this.ltr = false, this.keyboard});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.slate200)),
      child: Directionality(
        textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
        child: TextField(
          controller: controller,
          keyboardType: keyboard,
          textAlign: ltr ? TextAlign.left : TextAlign.right,
          style: const TextStyle(fontSize: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(fontSize: 14, color: C.slate400),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }
}

class _SelectBox extends StatelessWidget {
  final String? value;
  final String hint;
  final List<MapEntry<String, String>> items;
  final ValueChanged<String?> onChanged;

  const _SelectBox({required this.value, required this.hint, required this.items, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.slate200)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          isDense: true,
          hint: Text(hint, style: const TextStyle(fontSize: 14, color: C.slate400)),
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.circular(12),
          style: const TextStyle(fontSize: 14, color: C.slate800),
          items: items
              .map((e) => DropdownMenuItem<String>(
                    value: e.key,
                    child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 240), child: Text(e.value, overflow: TextOverflow.ellipsis)),
                  ))
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}

class _TimePill extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _TimePill({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: C.slate200),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 12, color: C.slate400),
            const SizedBox(width: 4),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: C.slate700)),
            ),
          ],
        ),
      ),
    );
  }
}
